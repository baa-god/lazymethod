from lazy import lazy, lazymethod
